# request the server restart
mkdir -p %{restart_flag_dir}
echo > %{restart_flag}
