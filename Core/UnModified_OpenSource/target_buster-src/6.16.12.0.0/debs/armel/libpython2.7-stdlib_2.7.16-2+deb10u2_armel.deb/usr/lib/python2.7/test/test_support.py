import sys
import test.support
sys.modules['test.test_support'] = test.support
