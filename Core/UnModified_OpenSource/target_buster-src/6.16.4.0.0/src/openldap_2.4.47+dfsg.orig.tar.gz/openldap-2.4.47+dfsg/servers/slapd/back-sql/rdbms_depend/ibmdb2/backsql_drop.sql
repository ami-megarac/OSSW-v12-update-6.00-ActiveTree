DROP TABLE ldap_referrals;
DROP TABLE ldap_entry_objclasses;
DROP TABLE ldap_attr_mappings;
DROP TABLE ldap_entries;
DROP TABLE ldap_oc_mappings;
