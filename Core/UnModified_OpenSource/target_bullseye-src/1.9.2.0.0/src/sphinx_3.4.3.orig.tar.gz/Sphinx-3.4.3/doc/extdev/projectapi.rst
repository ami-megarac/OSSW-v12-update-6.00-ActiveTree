.. _project-api:

Project API
===========

.. currentmodule:: sphinx.project

.. autoclass:: Project
   :members:
