=======================
Test HTML admonitions
=======================

.. seealso:: test

.. note:: test

.. warning:: test

.. attention:: test

.. caution:: test

.. danger:: test

.. error:: test

.. hint:: test

.. important:: test

.. tip:: test

