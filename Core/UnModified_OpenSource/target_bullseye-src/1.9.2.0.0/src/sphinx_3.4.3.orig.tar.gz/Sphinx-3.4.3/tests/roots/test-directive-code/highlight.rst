highlight
---------

.. code-block::

   "A code-block without no language"

.. code-block:: python2

   "A code-block with language argument"

.. highlight:: python3

.. code-block::

   "A code-block without no language after highlight directive"

.. code-block:: python2

   "A code-block without language argument after highlight directive"
