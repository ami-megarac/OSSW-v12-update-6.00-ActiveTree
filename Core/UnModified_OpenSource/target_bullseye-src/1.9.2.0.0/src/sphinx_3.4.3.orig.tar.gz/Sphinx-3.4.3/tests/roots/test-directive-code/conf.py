exclude_patterns = ['_build']
numfig = True
