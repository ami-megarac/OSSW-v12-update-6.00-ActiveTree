.. _foo:

foo/index
=========

.. toctree::

   foo_1
   foo_2
